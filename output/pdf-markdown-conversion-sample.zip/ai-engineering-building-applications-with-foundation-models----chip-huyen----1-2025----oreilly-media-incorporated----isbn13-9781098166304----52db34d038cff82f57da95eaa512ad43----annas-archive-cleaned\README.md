﻿# PDF to Markdown Conversion Sample

This sample demonstrates a structured PDF-to-Markdown conversion prepared for RAG and knowledge-management workflows.

## Included

- Chapter-level Markdown files in `chapters/`
- YAML frontmatter with title, author, source file, file type, chapter, and conversion date
- `index.md` linking to every chapter
- `quality-report.md` documenting conversion checks and known limitations

## Cleanup Performed

- Removed repeated PDF page headers and footers
- Removed standalone page numbers
- Repaired common PDF text-encoding artifacts
- Rejoined broken paragraph lines
- Preserved chapter titles, figures, tables, lists, citations, and footnotes as extracted text where possible
- Added consistent Markdown headings and metadata

## Known Limitations

Tables and figures are preserved as text descriptions rather than reconstructed visually. Scanned PDFs would require an OCR pass, which was not needed for this text-extractable source.

## Reproduce

Run `python convert.py` from the project root.
